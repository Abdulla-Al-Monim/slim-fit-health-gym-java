public class MemberInfo{
	private int id;
	private String name;
	private String address;
	private String phone;
        private int balance;
	public MemberInfo(int i,String n,String a,String p,int b){
		id = i;
                name= n;
                address = a;
                phone = p;
                balance =b;
	}
	public String getName(){return name;}
	public String getPhone(){return phone;}
	public String getAddress(){return address;}
	public int getId(){return id;}
        public int getBalance(){return balance;}
   
}