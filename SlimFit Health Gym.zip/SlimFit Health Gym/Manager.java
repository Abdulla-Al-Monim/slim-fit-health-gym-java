public class Manager{
	private int id;
	private float cgpa;
	private String uname;
	private String dept;
	private String pass;
	public Manager(String n,String p){
		uname=n;
		pass=p;
	}
		public String getName(){
		return uname;
	}
	public String getPassword(){
		return pass;
	}
        	public void print(){
		System.out.print(uname);
		
	}
}
	