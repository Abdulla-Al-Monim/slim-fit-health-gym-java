import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.awt.Color;
import java.awt.Graphics;
public class Trainer extends Frame implements WindowListener, ActionListener{

	private Register register;
	private Button logOut;
        private Button back;


	public Trainer(Register r){
		super("SlimFit Health Gym");
		this.register=r;
		
                ImageIcon ic=new ImageIcon(getClass().getResource("img.jpg")); 
		this.setIconImage(ic.getImage());
            
            
            
	 Label l1=new Label("Trainer name   phone     Address    salary");
		Label l2=new Label("monim    01779251787     tangail      10000");
		Label l3=new Label("shuvo    01712154865     chadpur      13000");
		Label l4=new Label("rasel    01735087433     kalihati         15000");
		add(l1);
		add(l2);
		add(l3);
		add(l4);
        logOut = new Button("Log Out");
        back = new Button("Back");
        add(back);
	    add(logOut);
		l1.setBounds(120,40,250,30);
		l2.setBounds(120,80,600,30);
		l3.setBounds(120,120,600,30);
		l4.setBounds(120,160,600,30);
		logOut.setBounds(120,200,50,25);
                back.setBounds(300,200,50,25);
		setSize(800,400);
		setBackground(Color.GRAY);
                l1.setBackground(Color.black);
		l1.setForeground(Color.WHITE);
		
		setLayout(null);
		addWindowListener(this);
		logOut.addActionListener(this);
                back.addActionListener(this);
	}
		public void paint(Graphics g){
		
	}
	public void windowClosing(WindowEvent we){
 
		System.exit(0);
	}
	public void actionPerformed(ActionEvent e){
		String s=e.getActionCommand();
		if(s.equals("Log Out")){
			register.trainers.setVisible(false);
			register.log.setVisible(true);
		}
                else if(s.equals("Back")){
			register.trainers.setVisible(false);
			register.information.setVisible(true);
		}

	}
	public void windowActivated(WindowEvent e){}
	public void windowClosed(WindowEvent e){}
	public void windowDeactivated(WindowEvent e){}
	public void windowDeiconified(WindowEvent e){}
	public void windowIconified(WindowEvent e){}
	public void windowOpened(WindowEvent e){}
}