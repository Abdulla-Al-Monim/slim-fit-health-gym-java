public class ProjectBase{
	public static void main(String[] args){
		Register r = new Register();
		
		r.log= new LogInPage(r);
		r.sign = new SignUpPage(r);
		r.information = new Info(r);
		r.memberInfo = new Member(r);
		r.programs = new Program(r);
		r.trainers = new Trainer(r);
                r.row = new DeleteRow(r);
                r.update = new UpdateData(r);
                r.add = new AddMember(r);
		r.log.setVisible(true);
		
	}
        
}