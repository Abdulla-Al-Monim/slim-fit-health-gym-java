import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JLabel;
public class Buffer{
	private Manager List[];
	public MemberInfo memberList[];
        
	
	public Buffer(int size){
		List=new Manager[size]; 
                memberList=new MemberInfo[size];
	}
	public void loadManager(String sql)throws SQLException{
		DataAccess da=new DataAccess();
		ResultSet rs=da.getData(sql);
		Manager m=null;
		int id;
		String uName;
		String pass;
			while(rs.next()){
				
		    id=rs.getInt("id"); 
			uName=rs.getString("uName");
			
			pass=rs.getString("pass");
			
			m=new Manager(uName,pass);
			addManager(m);
		}
		
	}
		public boolean check(String uName,String pass){
		boolean flag=false;
		for(Manager m:List){
			if(m!=null){
				if(m.getName().equals(uName) && m.getPassword().equals(pass))
                                {
					flag=true;
				}
			}
		}
		return flag;
	}
	public void addManager(Manager m){
		for(int i=0;i<List.length;i++){
			if(List[i]==null){
				List[i]=m;break;
			}
		}
	}
        
        
        
        	public void addMember(MemberInfo c){
		for(int i=0;i<memberList.length;i++){
			if(memberList[i]==null){
				memberList[i]=c;
				break;
			}
		}
	}
                
	public void loadMember(String sql){
		
		try{
			DataAccess da=new DataAccess();
			ResultSet rs=da.getData(sql);
			MemberInfo c=null;
			while(rs.next()){
				c=new MemberInfo(rs.getInt("id"),rs.getString("name"),rs.getString("address"),rs.getString("phone"),rs.getInt("balance"));
				addMember(c);
				
			}
			
			
			
		}
		catch(Exception ex){
			ex.printStackTrace();
		}
	}
	public void showAllMember(JLabel l){

		String s="<html>";
		System.out.println("hello");
		for(MemberInfo r:memberList){
			if(r!=null){
				s=s+r.getId()+" "+" "+" "+" "+r.getName()+" "+r.getAddress()+" "+r.getPhone()+" "+r.getBalance()+"<br/>";
				System.out.println(s);
				
			}
		}
		s+="</html>";
		l.setText(s);
	}
        
        
        
        
        
        
}


	