import java.awt.Button;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.Label;
import javax.swing.JLabel;
import javax.swing.JFrame;
import java.awt.TextField;
import java.awt.event.ActionListener;
import java.awt.event.KeyListener;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;

public class Member extends JFrame implements ActionListener{
    private Register register;
    public JLabel show;
   
	//private TextField emailText;
	
	public Member(Register r){
		super("SlimFit Health Gym");
		this.register=r;
                Label a= new Label("id         Name         Address      Phone      Balance");
                a.setBounds(20,50,300,20);
		Button b=new Button("Show All");
                Button logOut = new Button("Log Out");
                Button back = new Button("Back");
                Button add = new Button("Add");
                show=new JLabel("Data to show");
                show.setBounds(20,20,500,200);
                
		b.setBounds(20,250,50,25);
                logOut.setBounds(90,250,50,25);
                back.setBounds(160,250,50,25);
                add.setBounds(250,250,50,25);
                add(a);
                add(b);
		add(show);
                add(logOut);
                add(back);
                add(add);

		setSize(800,400);
		b.addActionListener(this);
                logOut.addActionListener(this);
                back.addActionListener(this);
                add.addActionListener(this);
                
		setLayout(null);
	}
	public void actionPerformed(ActionEvent ae){
		String st=ae.getActionCommand();
		if(st.equals("Show All")){
			register.b.loadMember("select * from member");
			register.b.showAllMember(show);
		}
              	else if(st.equals("Log Out")){
			register.memberInfo.setVisible(false);
			register.log.setVisible(true);
		}
        	else if(st.equals("Back")){
			register.memberInfo.setVisible(false);
			register.information.setVisible(true);
		}
              	else if(st.equals("Add")){
			register.memberInfo.setVisible(false);
			register.add.setVisible(true);
		}
	}
	public void paint(Graphics g){
            g.drawString("id ",20,10);
	}


   
}