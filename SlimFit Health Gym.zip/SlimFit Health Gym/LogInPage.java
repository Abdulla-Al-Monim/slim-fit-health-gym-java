import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.awt.Color;
import java.awt.Graphics;

class LogInPage extends Frame implements WindowListener, ActionListener{
	
    
	private Register register;
	public Button logInButtton;
	public Button signUpButton;
	public TextField uName;
    private ImageIcon ic;
	public TextField password;
	public LogInPage(Register r){
		super("SlimFit Health Gym");
		this.register=r;

		ic=new ImageIcon(getClass().getResource("img.jpg")); 
		this.setIconImage(ic.getImage());
		logInButtton = new Button("log In");
		signUpButton=new Button("Sign up");
		uName = new TextField();
		password = new TextField();
		add(uName);
		add(password);
		add(logInButtton);
		add(signUpButton);
		setSize(800,400);
		setBackground(Color.GRAY);
		logInButtton.setBackground(Color.BLACK);
		logInButtton.setForeground(Color.magenta);
		setLayout(null);
	    uName.setBounds(120,80,150,30);
		
		password.setBounds(120,130,150,30);
                password.setEchoChar('*');
		logInButtton.setBounds(60,200,80,30);

		signUpButton.setBounds(180,200,80,30);
		addWindowListener(this);
		logInButtton.addActionListener(this);
		signUpButton.addActionListener(this);
		
	}
 
	public void paint(Graphics g){


		g.drawString("User Name:",40,100);
		g.drawString("Password:",40,150);
	}
	public void windowClosing(WindowEvent we){
		System.exit(0);
	}
	public void actionPerformed(ActionEvent e){
		String s=e.getActionCommand();
		boolean b=false;
		if(s.equals("log In")){
                try{
				register.b.loadManager("select * from checking");
				//register.buffer.printAllStudents();
				b=register.b.check(uName.getText(),password.getText());
				if(b==true){
					System.out.println("Valid User");
					register.information.setVisible(true);
					register.log.setVisible(false);
				}
				else{
					System.out.println("Invalid User");
				}
			}
			catch(Exception ex){ex.printStackTrace();}
		}
		else if(s.equals("Sign up")){
			register.log.setVisible(false);
			register.sign.setVisible(true);
		}
	}
	public void windowActivated(WindowEvent e){}
	public void windowClosed(WindowEvent e){}
	public void windowDeactivated(WindowEvent e){}
	public void windowDeiconified(WindowEvent e){}
	public void windowIconified(WindowEvent e){}
	public void windowOpened(WindowEvent e){}

}