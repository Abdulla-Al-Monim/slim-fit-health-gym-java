import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.awt.Color;
import java.awt.Graphics;

 public class Info extends JFrame implements WindowListener, ActionListener{
 
	private Register register;

        private JLabel imgLavel;
	private ImageIcon img;
	private Button memberInfo;
	private Button trainerInfo;
	private Button program;
	private Button logOut;
	public Info(Register r){
            super("SlimFit Health Gym");
		this.register=r;
               
               setBackground(Color.GRAY);
                
        ImageIcon ic=new ImageIcon(getClass().getResource("img.jpg")); 
		this.setIconImage(ic.getImage());
		setBackground(Color.GRAY);
	    memberInfo = new Button("Member");
		trainerInfo = new Button("Trainer");
		program = new Button("Progran");
		logOut = new Button("Log Out");
		add(memberInfo);
		add(trainerInfo);
		add(program);
		add(logOut);
		setSize(800,400);
		setLayout(new FlowLayout());
		addWindowListener(this);
		memberInfo.addActionListener(this);
		trainerInfo.addActionListener(this);
		program.addActionListener(this);
		logOut.addActionListener(this);
		
	}


public void paint(Graphics g){
		
	}
	public void windowClosing(WindowEvent we){
        System.out.println("Window is closing");
		System.exit(0);
	}
	public void actionPerformed(ActionEvent e){
		String s=e.getActionCommand();
		if(s.equals("Member")){
			register.information.setVisible(false);
			register.memberInfo.setVisible(true);
		}
		else if(s.equals("Trainer")){
			register.information.setVisible(false);
			register.trainers.setVisible(true);
		}	
		else if(s.equals("Progran")){
			register.information.setVisible(false);
			register.programs.setVisible(true);		
		}
		else if(s.equals("Log Out")){
			register.information.setVisible(false);
			register.log.setVisible(true);
		}
	}
	public void windowActivated(WindowEvent e){}
	public void windowClosed(WindowEvent e){}
	public void windowDeactivated(WindowEvent e){}
	public void windowDeiconified(WindowEvent e){}
	public void windowIconified(WindowEvent e){}
	public void windowOpened(WindowEvent e){}



}