
import java.awt.Button;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.Label;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;



public class UpdateData extends Frame implements WindowListener, ActionListener{

	private Register register;
        private TextField id;
 
        private Button update;

	private TextField pass;

	private Button backButton;

    public UpdateData(Register r){
        super("SlimFit Health Gym");
		this.register=r;
                ImageIcon ic=new ImageIcon(getClass().getResource("img.jpg")); 
		this.setIconImage(ic.getImage());            
                id = new TextField(10);
		
		pass=new TextField(10);
                Label i = new Label("User Id: ");
		
		Label el=new Label("New Password: ");

             
		backButton=new Button("Back");
                add(i);
                add(id);
		
		add(el);
		add(pass);

           
		add(backButton);
                update = new Button("Confirm");
                
             
                add(update);
		setSize(1000,400);
		setLayout(new FlowLayout());
		addWindowListener(this);
               

                update.addActionListener(this);
                backButton.addActionListener(this);
    }

    


    public void windowOpened(WindowEvent we) {
       
    }


    public void windowClosing(WindowEvent we) {
       System.exit(0);
    }



    public void windowClosed(WindowEvent we) {
       
    }


    public void windowIconified(WindowEvent we) {
       
    }


    public void windowDeiconified(WindowEvent we) {
      
    }


    public void windowActivated(WindowEvent we) {
        
    }


    public void windowDeactivated(WindowEvent we) {
      
    }


    public void actionPerformed(ActionEvent e) {
       String s=e.getActionCommand();
       DataAccess da=new DataAccess();
       if(s.equals("Back")){
            register.sign.setVisible(true);
            register.update.setVisible(false);
    }
       else if(s.equals("Confirm")){
            String sql="UPDATE checking SET pass= "+pass.getText()+" where "+id.getText()+" ";
             da.updateDB(sql);

            System.out.println(sql);
    } 
}

}