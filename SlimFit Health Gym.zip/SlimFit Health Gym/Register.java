public class Register{
	public Buffer b;
	public LogInPage log;
	public SignUpPage sign;
    public DeleteRow row;
	public Info information;
	public Member memberInfo;
	public Program programs;
	public 	Trainer trainers;
        public UpdateData update;
        public AddMember add;
	public Register(){
		b = new Buffer(20);
		log = null;
		sign=null;
		information = null;
		memberInfo = null;
		programs = null;
		trainers= null;
                row= null;
                update = null;
                add= null;
	}
}